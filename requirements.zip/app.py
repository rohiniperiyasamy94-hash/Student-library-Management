from flask import Flask, request, redirect
import pyodbc

app = Flask(__name__)

SERVER = "libraryyy.database.windows.net"
DATABASE = "library"
USERNAME = "rohini"
PASSWORD = "roh12345678@"

CONNECTION_STRING = f"""
DRIVER={{ODBC Driver 17 for SQL Server}};
SERVER={SERVER};
PORT=1433;
DATABASE={DATABASE};
UID={USERNAME};
PWD={PASSWORD};
Encrypt=yes;
TrustServerCertificate=no;
Connection Timeout=30;
"""

def get_connection():
    return pyodbc.connect(CONNECTION_STRING)


# READ USERS
@app.route("/")
def index():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users")
    rows = cursor.fetchall()
    conn.close()

    html = """
    <html>
    <head>
    <title>Student library management</title>

    <style>

    body{
        font-family: Arial;
        background:#f4f6f8;
        padding:40px;
    }

    .container{
        width:700px;
        margin:auto;
        background:white;
        padding:30px;
        border-radius:10px;
        box-shadow:0 4px 10px rgba(0,0,0,0.1);
    }

    h2{
        text-align:center;
        color:#333;
    }

    table{
        width:100%;
        border-collapse:collapse;
        margin-top:20px;
    }

    th,td{
        padding:12px;
        border-bottom:1px solid #ddd;
        text-align:left;
    }

    th{
        background:#1976d2;
        color:white;
    }

    a.button{
        text-decoration:none;
        padding:6px 12px;
        border-radius:4px;
        color:white;
        font-size:14px;
    }

    .add{
        background:#2e7d32;
        padding:10px 16px;
        display:inline-block;
        margin-bottom:15px;
    }

    .edit{
        background:#f9a825;
    }

    .delete{
        background:#c62828;
    }

    </style>
    </head>

    <body>
    <div class="container">

    <h2>Student library management</h2>

    <a class="button add" href="/add">Add User</a>

    <table>

    <tr>
        <th>ID</th>
        <th>title</th>
        <th>author</th>
        <th>isbnnumber</th>
        <th>Actions</th>
    </tr>
    """

    for row in rows:
        html += f"""
        <tr>
        <td>{row.id}</td>
        <td>{row.title}</td>
        <td>{row.isbnnumber}</td>
        <td>{row.author}</td>
        <td>
        <a class="button edit" href="/edit/{row.id}">Edit</a>
        <a class="button delete" href="/delete/{row.id}">Delete</a>
        </td>
        </tr>
        """

    html += """
    </table>
    </div>
    </body>
    </html>
    """

    return html


# ADD USER
@app.route("/add", methods=["GET","POST"])
def add():

    if request.method == "POST":

        title = request.form["title"]
        isbnnumber= request.form["isbnnumber"]
        author=request.form["author"]

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            "INSERT INTO users (title,isbnnumber,author) VALUES (?,?,?)",
            title,isbnnumber,author)
        

        conn.commit()
        conn.close()

        return redirect("/")

    return """

    <style>

    body{
        font-family:Arial;
        background:#f4f6f8;
        padding:40px;
    }

    .card{
        width:400px;
        margin:auto;
        background:white;
        padding:30px;
        border-radius:10px;
        box-shadow:0 4px 10px rgba(0,0,0,0.1);
    }

    input{
        width:100%;
        padding:10px;
        margin-top:10px;
        margin-bottom:15px;
        border:1px solid #ccc;
        border-radius:4px;
    }

    button{
        background:#1976d2;
        color:white;
        border:none;
        padding:10px 15px;
        border-radius:4px;
        cursor:pointer;
    }

    </style>

    <div class="card">

    <h2>Add User</h2>

    <form method="post">

    title
    <input name="title">

    isbnnumber
    <input name="isbnnumberl">

     author
     <input name="author">

    <button type="submit">Save</button>

    </form>

    </div>
    """


# UPDATE USER
@app.route("/edit/<int:user_id>", methods=["GET","POST"])
def edit(user_id):

    conn = get_connection()
    cursor = conn.cursor()

    if request.method == "POST":

        title= request.form["title"]
        isbnnumber= request.form["isbnnumber"]
        author=request.form["author"]

        cursor.execute(
            "UPDATE users SET title=?, isbnnumber=? ,author=?",
            title,isbnnumber,author
        )

        conn.commit()
        conn.close()

        return redirect("/")

    cursor.execute("SELECT * FROM users WHERE id=?",user_id)
    user = cursor.fetchone()

    conn.close()

    return f"""

    <style>

    body{{
        font-family:Arial;
        background:#f4f6f8;
        padding:40px;
    }}

    .card{{
        width:400px;
        margin:auto;
        background:white;
        padding:30px;
        border-radius:10px;
        box-shadow:0 4px 10px rgba(0,0,0,0.1);
    }}

    input{{
        width:100%;
        padding:10px;
        margin-top:10px;
        margin-bottom:15px;
        border:1px solid #ccc;
        border-radius:4px;
    }}

    button{{
        background:#f9a825;
        color:white;
        border:none;
        padding:10px 15px;
        border-radius:4px;
        cursor:pointer;
    }}

    </style>

    <div class="card">

    <h2>Edit student library record</h2>

    <form method="post">

    title
    <input name="title" value="{user.title}">

    isbnnumber
    <input name="isbnnumber" value="{user.isbnnumber}">

    author
    <input name="author" value="{user.author}">


    <button type="submit">Update</button>

    </form>

    </div>
    """


# DELETE USER
@app.route("/delete/<int:user_id>")
def delete(user_id):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM users WHERE id=?",user_id)

    conn.commit()
    conn.close()

    return redirect("/")


if __name__ == "__main__":
    app.run()